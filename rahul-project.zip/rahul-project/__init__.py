from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import hashlib
import datetime
import json
import pickle
import numpy as np
from bs4 import BeautifulSoup
import requests
import re



app = Flask(__name__)

app.secret_key = '3242353645646'


TAG_RE = re.compile(r'<[^>]+>')

def remove_tags(text):
    return TAG_RE.sub('', text)


@app.route('/')
def login():
    return render_template('login.html')


@app.route('/request',methods=['POST'])
def hello_world():
   import requests
   rahul = request.form['Name']
   rahul1 = json.loads(rahul)

   check_result = model.predict([[rahul1]])

   flash("Salary must be around "+str(int(check_result)))

   return redirect(url_for('dashboard'))


@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        username = session['username']
        return render_template('modle.html', now=datetime.datetime.now())
    else:
        return redirect(url_for('login'))




@app.route('/login-check', methods = ['POST'])
def checkLogin():
    if request.method == 'POST':
        email = str(request.form['email'])
        password = str(request.form['password'])
        if request.method == 'POST':
            if request.form['email'] != 'rahul.pant@adaan.com' or request.form['password'] != 'rahul2336':
                flash("Invalid Credentials")
                return redirect(url_for('login'))
            else:
                data = ('Rahul',request.form['email'],request.form['password'],1)
                session['username'] = data
                return redirect(url_for('dashboard'))




@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))



@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html")


#KNN IRIS
# Loading model to compare the results
iris_model = pickle.load(open('knn_iris_model.pkl','rb'))
@app.route('/knn_iris')
def knnIris():
    if 'username' in session:
        username = session['username']
        return render_template('knn_iris.html', now=datetime.datetime.now())
    else:
        return redirect(url_for('login'))


@app.route('/request_iris',methods=['POST'])
def modelIris():
   import requests
   sepal_length = request.form['sepal_length']
   sepal_width = request.form['sepal_width']
   petal_length = request.form['petal_length']
   petal_width = request.form['petal_width']
   sepal_length_json = json.loads(sepal_length)
   sepal_width_json = json.loads(sepal_width)
   petal_length_json = json.loads(petal_length)
   petal_width_json = json.loads(petal_width)

   check_result = iris_model.predict(np.asarray([[sepal_length_json,sepal_width_json,petal_length_json,petal_width_json]]))

   flash("Category of iris flower is "+str(check_result[0]))

   return redirect(url_for('knnIris'))


#Linear Regression ADS
# Loading model to compare the results
ads_model = pickle.load(open('linearRegression_ads_model.pkl','rb'))

@app.route('/linear_regression_ads')
def linearRegressionAds():
    if 'username' in session:
        username = session['username']
        return render_template('linear_regression_ads.html', now=datetime.datetime.now())
    else:
        return redirect(url_for('login'))

@app.route('/request_ads',methods=['POST'])
def modelAds():
   import requests
   tv_invest = request.form['tv_invest']
   radio_invest = request.form['radio_invest']
   newspaper_invest = request.form['newspaper_invest']
   tv_invest_json = json.loads(tv_invest)
   radio_invest_json = json.loads(radio_invest)
   newspaper_invest_json = json.loads(newspaper_invest)

   check_result = ads_model.predict(np.asarray([[tv_invest_json,radio_invest_json,newspaper_invest_json]]))

   flash("Number of sales will be "+str(round(check_result[0],2)))

   return redirect(url_for('linearRegressionAds'))


#web Scraping
@app.route('/web_scraping')
def webScraping():
        if 'username' in session:
            username = session['username']
            return render_template('web_scraping.html', now=datetime.datetime.now())
        else:
            return redirect(url_for('login'))

@app.route('/request_scraping',methods=['POST'])
def modelScraping():
  import requests
  request_url = request.form['url']
  #request_url_json = json.loads(request_url)
  result = requests.get(request_url)
  webpage = result.content
  sl_soup = BeautifulSoup(webpage, 'html.parser')
  result.close()

  links = []
  img_links = []
  product_names = []



  for href in sl_soup.findAll('a',href=True):
      links.append(href['href'])

  for src in sl_soup.findAll('img',src=True):
      img_links.append(src['src'])



  #product_names = sl_soup.findAll(class_='EIR5N')

  remove_tag_title = remove_tags(str(sl_soup.title))
  remove_href_title = remove_tags(str(links))
  remove_img_title = remove_tags(str(img_links))

  flash("Title of the website is:  "+str(remove_tag_title))
  flash("Links on the website is:  "+str(remove_href_title))
  flash("Image links on the website is:  "+str(remove_img_title))

  return redirect(url_for('webScraping'))



if __name__ == "__main__":
    app.run(debug=True)
